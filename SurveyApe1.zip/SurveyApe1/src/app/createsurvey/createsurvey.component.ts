import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-createsurvey',
  templateUrl: './createsurvey.component.html',
  styleUrls: ['./createsurvey.component.css']
})
export class CreatesurveyComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
